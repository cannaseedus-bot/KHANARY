KHANARY driver DLLs - unzip into the repo root
==============================================

These DLLs ship as a zip because GitHub's malware scanner flags raw
.dll files on push. They are NOT malware - they are the compiled output
of the tracked C++ sources in this repo:

  drivers/*.cpp/.h            -> drivers/*.dll
  bridges/ggml-xcfe/xcfe_gl_ops.cpp -> bridges/ggml-xcfe/xcfe_gl_ops.dll
  wgpu_native-release.dll      -> official wgpu-native WebGPU library (8.4 MB)

TO INSTALL: unzip this archive at the repository root
(C:\Users\canna\_khanary_inspect\ or wherever you cloned KHANARY).
The paths inside mirror the repo layout, so every DLL lands in the
folder the runtime expects:

  bridges/ggml-xcfe/wgpu/wgpu_native-release.dll   (loaded by xcfe_gl_ops.dll)
  bridges/ggml-xcfe/xcfe_gl_ops.dll                (loaded by ggml-xcfe.dll)
  drivers/*.dll                                    (loaded by kuhul-server.cjs via ffi/koffi)

REBUILD FROM SOURCE instead (no zip needed):
  cd drivers && build_drivers.bat        (all 5 source-only driver DLLs)
  cl /std:c++17 /O2 /LD bridges/ggml-xcfe/xcfe_gl_ops.cpp  (xcfe_gl_ops.dll)
  wgpu_native-release.dll: download from https://github.com/wgpu/wgpu-native/releases
