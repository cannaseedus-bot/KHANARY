KHANARY geometry — D3D11 verification binaries
================================================
Built and run on Intel HD Graphics 4600 (D3D11 feature level 11_1, 0xb100).
These are the runnable harnesses that produced the bit-exact (max abs err 0.00e+00)
verification recorded in ../models/khanary-geometry-v0.3.0/MODEL.json.

Included (Windows x64, HD4600/D3D11-specific — will not run elsewhere):
  xform_run.exe        vertex-transform kernel dispatch + CPU compare (256 verts)
  skin_run.exe         weighted-skinning kernel, position+normal (128 verts)
  brain_xform_run.exe  transforms the real 30628-vertex brain2 birdsong mesh

TO UNZIP:  extract into this scratch/ folder, then run each .exe FROM scratch/
           (they read sibling inputs: *.hlsl, brain_verts.bin, brain_N.txt).

REBUILD instead (source is tracked): compile the sibling xform_run.cpp / skin_run.cpp /
brain_xform_run.cpp with build_brain.bat (vcvars64 + cl /std:c++17). Regenerate inputs:
  python ../tools/build_geometry_model.py     # emits kernels
  # brain_verts.bin: read models/.../data/birdsong_mesh.stb tensors 0/1/2 as float3

EXCLUDED (not needed — pure build intermediates / trivially rebuildable):
  *.obj (linker intermediates), *.cso (fxc output of the .hlsl), *.bin (from the .stb).
