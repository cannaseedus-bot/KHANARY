KHANARY D3D11 verification binaries (HD 4600, FL 11_1).

matmul_run.exe  G_MATMUL cs_5_0 GEMM on a real gpt2 weight (needs gemm_A.bin/gemm_B.bin/
                gemm_Cref.bin/gemm_dims.txt/knu_matmul.hlsl beside it; regen via
                python ../tools/safetensors_to_stb.py + the prep in the model notes).
